<div id='context-block-addable-<?php print $bid ?>' class='context-block-item context-block-addable clearfix'>
  <span class='icon'></span>
  <?php print $info ?>
</div>
