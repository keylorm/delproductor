<?php
require 'vendor/autoload.php';
\Yotpo\Bootstrap::init();

